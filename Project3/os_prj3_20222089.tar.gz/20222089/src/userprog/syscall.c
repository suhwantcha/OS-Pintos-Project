#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "userprog/process.h"
#include "userprog/pagedir.h"
#include <string.h>
#include <stdint.h>
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);
static struct lock file_lock;

static void check_buffer(const void *buffer, unsigned size){
    const char *ptr = (const char *)buffer;
    for(unsigned i = 0; i < size; i++){
        check_user_vaddr(ptr + i);
    }
}

void check_user_vaddr(const void *vaddr){
    if (vaddr == NULL || !is_user_vaddr(vaddr) || pagedir_get_page(thread_current() -> pagedir, vaddr) == NULL){
        syscall_exit(-1);
    }
}

void
syscall_init (void)
{
    lock_init(&file_lock);
    intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void syscall_halt(void){
    shutdown_power_off();
}

void syscall_exit(int status){
    struct thread *t = thread_current();
    printf("%s: exit(%d)\n", t->name, status);
    t->exit_status = status;
    sema_up(&t->exit_sema);
    thread_exit();
}

int syscall_exec(const char *cmd_line){
    tid_t tid = process_execute(cmd_line);
    struct thread *child = get_child_process(tid);
    if(child == NULL) return -1;
    sema_down(&child->load_sema);
    return child->load_success ? tid : -1;
}

int syscall_wait(int pid){
    return process_wait(pid);
}

bool syscall_create(const char *file, unsigned initial_size){
    if(file == NULL) syscall_exit(-1);
    lock_acquire(&file_lock);
    bool success = filesys_create(file, initial_size);
    lock_release(&file_lock);
    return success;
}

bool syscall_remove(const char *file){
    if(file == NULL) syscall_exit(-1);
    lock_acquire(&file_lock);
    bool success = filesys_remove(file);
    lock_release(&file_lock);
    return success;
}

int syscall_open(const char *file){
    if(file == NULL) syscall_exit(-1);
    lock_acquire(&file_lock);
    struct file *f = filesys_open(file);
    int fd = f ? fd_add(f) : -1;
    lock_release(&file_lock);
    return fd;
}
int syscall_filesize(int fd){
    struct file *f = fd_get(fd);
    if(f == NULL) syscall_exit(-1);
    lock_acquire(&file_lock);
    int size = file_length(f);
    lock_release(&file_lock);
    return size;
}


int syscall_read(int fd, void *buffer, unsigned size){
    check_buffer(buffer, size);
    if(fd < 0 || fd == 1) syscall_exit(-1);
    lock_acquire(&file_lock);
    int bytes_read = 0;
    if(fd == 0){
        for(unsigned i = 0; i < size; i++){
            *((char *)buffer + i) = input_getc();
            bytes_read++;
        }
    }else {
        struct file *f = fd_get(fd);
        if(f == NULL){
            lock_release(&file_lock);
            syscall_exit(-1);
        }
        bytes_read = file_read(f, buffer, size);
    }
    lock_release(&file_lock);
    return bytes_read;
}

int syscall_write(int fd, const void *buffer, unsigned size){
    check_buffer(buffer, size);
    if(fd <= 0)syscall_exit(-1);
    lock_acquire(&file_lock);
    int bytes_written = 0;
    if(fd == 1){
        putbuf(buffer, size);
        bytes_written = size;
    }else {
        struct file *f = fd_get(fd);
        if(f == NULL){
            lock_release(&file_lock);
            syscall_exit(-1);
        }
        bytes_written = file_write(f, buffer, size);
    }
    lock_release(&file_lock);
    return bytes_written;
}
void syscall_seek(int fd, unsigned position){
    struct file *f = fd_get(fd);
    if(f == NULL) syscall_exit(-1);
    lock_acquire(&file_lock);
    file_seek(f, position);
    lock_release(&file_lock);
}

unsigned syscall_tell(int fd){
    struct file *f = fd_get(fd);
    if(f == NULL) syscall_exit(-1);
    lock_acquire(&file_lock);
    unsigned pos = file_tell(f);
    lock_release(&file_lock);
    return pos;
}
void syscall_close(int fd){
    lock_acquire(&file_lock);
    fd_remove(fd);
    lock_release(&file_lock);
}

int fibonacci(int n) {
    if (n < 0) return -1;
    if (n == 0) return 0;
    if (n == 1) return 1;

    int a = 0;
    int b = 1;
    int next;

    for (int i = 2; i <= n; i++) {
        next = a + b;
        a = b;
        b = next;
    }
    return b;
}

int max_of_four_int(int a, int b, int c, int d) {
    int max = a;
    if (b > max) max = b;
    if (c > max) max = c;
    if (d > max) max = d;
    return max;
}



static void
syscall_handler (struct intr_frame *f UNUSED)
{
    int syscall_num;
    int *args = (int *)f->esp;

    check_user_vaddr(f->esp);
    syscall_num = args[0];

    switch(syscall_num){
        case SYS_HALT:
            syscall_halt();
            break;

        case SYS_EXIT:
            check_user_vaddr(&args[1]);
            syscall_exit(args[1]);
            break;

        case SYS_EXEC:
            check_user_vaddr(&args[1]);
            f->eax = syscall_exec((const char *)args[1]);
            break;

        case SYS_WAIT:
            check_user_vaddr(&args[1]);
            f->eax = syscall_wait(args[1]);
            break;

        case SYS_CREATE:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            f->eax = syscall_create((const char *)args[1], (unsigned)args[2]);
            break;

        case SYS_REMOVE:
            check_user_vaddr(&args[1]);
            f->eax = syscall_remove((const char *)args[1]);
            break;

        case SYS_OPEN:
            check_user_vaddr(&args[1]);
            f->eax = syscall_open((const char *)args[1]);
            break;

        case SYS_FILESIZE:
            check_user_vaddr(&args[1]);
            f->eax = syscall_filesize(args[1]);
            break;

        case SYS_READ:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            check_user_vaddr(&args[3]);
            f->eax = syscall_read(args[1], (void *)args[2], (unsigned)args[3]);
            break;

        case SYS_WRITE:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            check_user_vaddr(&args[3]);
            f->eax = syscall_write(args[1], (const void *)args[2], (unsigned)args[3]);
            break;

        case SYS_SEEK:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            syscall_seek(args[1], (unsigned)args[2]);
            break;

        case SYS_TELL:
            check_user_vaddr(&args[1]);
            f->eax = syscall_tell(args[1]);
            break;

        case SYS_CLOSE:
            check_user_vaddr(&args[1]);
            syscall_close(args[1]);
            break;

        case SYS_FIBONACCI:
            check_user_vaddr(&args[1]);
            f->eax = fibonacci(args[1]);
            break;

        case SYS_MAX_OF_FOUR_INT:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            check_user_vaddr(&args[3]);
            check_user_vaddr(&args[4]);
            f->eax = max_of_four_int(args[1], args[2], args[3], args[4]);
            break;


        default:
            thread_exit();
    }
}
