#ifndef THREADS_FIXED_POINT_H
#define THREADS_FIXED_POINT_H

#define FP_SHIFT 14

#define fp_from_int(n) ((int32_t)(n) << FP_SHIFT)

#define fp_to_int(fp) ((fp) / (1 << FP_SHIFT))

#define fp_to_int_round(fp) \
  (((fp) >= 0) ? (((fp) + (1 << (FP_SHIFT - 1))) >> FP_SHIFT) \
               : (((fp) - (1 << (FP_SHIFT - 1))) >> FP_SHIFT))

#define fp_add(a, b) ((a) + (b))

#define fp_sub(a, b) ((a) - (b))

#define fp_add_int(a, n) ((a) + fp_from_int(n))

#define fp_sub_int(a, n) ((a) - fp_from_int(n))

#define fp_mul(a, b) ((int32_t)(((int64_t)(a) * (b)) >> FP_SHIFT))

#define fp_mul_int(a, n) ((a) * (n))

#define fp_div(a, b) ((int32_t)(((int64_t)(a) << FP_SHIFT) / (b)))

#define fp_div_int(a, n) ((a) / (n))

#endif