#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"
#include "filesys/file.h"

tid_t process_execute (const char *file_name);
int process_wait (tid_t tid);
void process_exit (void);
void process_activate (void);
void construct_stack (const char *file_name, void **esp);
struct thread *get_child_process(tid_t tid);
int fd_add(struct file *f);
struct file *fd_get(int fd);
void fd_remove(int fd);

#endif /* userprog/process.h */
