#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "userprog/process.h"
#include "userprog/pagedir.h"
#include <string.h>
#include <stdint.h>

static void syscall_handler (struct intr_frame *);

void check_user_vaddr(const void *vaddr){
    if (vaddr == NULL || !is_user_vaddr(vaddr) || pagedir_get_page(thread_current() -> pagedir, vaddr) == NULL){
        syscall_exit(-1);
    }
}

void
syscall_init (void)
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void syscall_halt(void){
    shutdown_power_off();
}

void syscall_exit(int status){
    struct thread *t = thread_current();
    printf("%s: exit(%d)\n", t->name, status);
    t->exit_status = status;
    thread_exit();
}

int syscall_exec(const char *cmd_line){
    return process_execute(cmd_line);
}

int syscall_wait(int pid){
    return process_wait(pid);
}

int syscall_read(int fd, void *buffer, unsigned size){
    if(fd == 0){
        unsigned i;
        for(i = 0; i < size; i++){
            *((char *)buffer + i) = input_getc();
        }
        return size;
    }
    return -1;
}

int syscall_write(int fd, const void *buffer, unsigned size){
    if(fd == 1){
        putbuf(buffer, size);
        return size;
    }
    return -1;
}

int fibonacci(int n) {
    if (n < 0) return -1;
    if (n == 0) return 0;
    if (n == 1) return 1;

    int a = 0;
    int b = 1;
    int next;

    for (int i = 2; i <= n; i++) {
        next = a + b;
        a = b;
        b = next;
    }
    return b;
}

int max_of_four_int(int a, int b, int c, int d) {
    int max = a;
    if (b > max) max = b;
    if (c > max) max = c;
    if (d > max) max = d;
    return max;
}



static void
syscall_handler (struct intr_frame *f UNUSED)
{
    int syscall_num;
    int *args = (int *)f->esp;

    check_user_vaddr(f->esp);
    syscall_num = args[0];

    switch(syscall_num){
        case SYS_HALT:
            syscall_halt();
            break;

        case SYS_EXIT:
            check_user_vaddr(&args[1]);
            syscall_exit(args[1]);
            break;

        case SYS_EXEC:
            check_user_vaddr(&args[1]);
            f->eax = syscall_exec((const char *)args[1]);
            break;

        case SYS_WAIT:
            check_user_vaddr(&args[1]);
            f->eax = syscall_wait(args[1]);
            break;

        case SYS_READ:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            check_user_vaddr(&args[3]);
            f->eax = syscall_read(args[1], (void *)args[2], (unsigned)args[3]);
            break;

        case SYS_WRITE:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            check_user_vaddr(&args[3]);
            f->eax = syscall_write(args[1], (const void *)args[2], (unsigned)args[3]);
            break;

        case SYS_FIBONACCI:
            check_user_vaddr(&args[1]);
            f->eax = fibonacci(args[1]);
            break;

        case SYS_MAX_OF_FOUR_INT:
            check_user_vaddr(&args[1]);
            check_user_vaddr(&args[2]);
            check_user_vaddr(&args[3]);
            check_user_vaddr(&args[4]);
            f->eax = max_of_four_int(args[1], args[2], args[3], args[4]);
            break;

        default:
            thread_exit();
    }
}
